# SysDiagSuite

WPF (.NET 8) diagnostics app with Alpha (quick) and Omega (deep) protocols, packaged as MSIX.

## Build
1. Open the folder in **Visual Studio 2022**.
2. Add both projects to a new solution (or create one): `SysDiagSuite.App` and `SysDiagSuite.Package`.
3. Set **SysDiagSuite.Package** as Startup Project.
4. Build `Release | x64` and publish to create an **.msix**.

## Notes
- No admin required. Writes logs/reports to user profile.
- Reports are signed with a per-install RSA key stored under `%LOCALAPPDATA%\SysDiagSuite\keys`.
