namespace SysDiagSuite.Models
{
    public enum ProtocolMode
    {
        Alpha,
        Omega
    }
}
