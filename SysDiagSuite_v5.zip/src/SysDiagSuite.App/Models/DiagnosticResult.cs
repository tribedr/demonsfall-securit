namespace SysDiagSuite.Models
{
    public sealed class DiagnosticResult
    {
        public string Section { get; init; } = "";
        public string Text { get; init; } = "";
    }
}
