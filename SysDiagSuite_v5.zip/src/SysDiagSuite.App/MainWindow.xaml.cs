using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using SysDiagSuite.Models;
using SysDiagSuite.Services;
using SysDiagSuite.Windows;
using System.Runtime.InteropServices;

namespace SysDiagSuite
{
    public partial class MainWindow : Window
    {
        private readonly DiagnosticService _diag;
        private readonly ExternalDisplayService _display;
        private readonly SmartService _smart;
        private readonly GpuService _gpu;
        private readonly BatteryService _battery;
        private readonly NetworkService _network;
        private readonly SecurityService _security;
        private readonly LoggingService _log;
        private readonly SecurityMonitorService _secMon = new SecurityMonitorService();

        public MainWindow()
        {
            InitializeComponent();
            _diag = new DiagnosticService();
            _display = new ExternalDisplayService();
            _smart = new SmartService();
            _gpu = new GpuService();
            _battery = new BatteryService();
            _network = new NetworkService();
            _security = new SecurityService();
            _log = new LoggingService();
        }

        private ProtocolMode GetProtocol()
        {
            var selection = (ProtocolCombo.SelectedItem as System.Windows.Controls.ComboBoxItem)?.Content?.ToString() ?? "Alpha (Quick)";
            return selection.StartsWith("Alpha") ? ProtocolMode.Alpha : ProtocolMode.Omega;
        }

        private async void RunBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                RunBtn.IsEnabled = false;
                ExportBtn.IsEnabled = false;
                StatusText.Text = "Running diagnostics...";
                OutputBox.Clear();

                var mode = GetProtocol();

                var sb = new StringBuilder();
                sb.AppendLine($"Protocol: {mode}");
                sb.AppendLine($"Timestamp (UTC): {DateTime.UtcNow:O}");
                sb.AppendLine();

                var sys = await _diag.GetSystemInfoAsync();
                sb.AppendLine("[System]");
                sb.AppendLine(sys);

                var cpu = await _diag.CpuQuickAsync();
                sb.AppendLine("[CPU]");
                sb.AppendLine(cpu);

                var mem = await _diag.MemoryAsync();
                sb.AppendLine("[Memory]");
                sb.AppendLine(mem);

                if (mode == ProtocolMode.Omega)
                {
                    var disk = await _diag.DiskDeepAsync();
                    sb.AppendLine("[Disk]");
                    sb.AppendLine(disk);
                }

                var net = await _network.NetworkSummaryAsync(mode);
                sb.AppendLine("[Network]");
                sb.AppendLine(net);

                                if (mode == ProtocolMode.Omega)
                {
                    var smart = await _smart.GetSmartSummaryAsync();
                    sb.AppendLine("[GPU]");
                    sb.AppendLine(await _gpu.GetGpuSummaryAsync());

                    sb.AppendLine("[Battery]");
                    sb.AppendLine(await _battery.GetBatterySummaryAsync());

                    sb.AppendLine("[SMART]");
                    sb.AppendLine(smart);

                    sb.AppendLine("[Security: Omega]");
                    sb.AppendLine($"Running as MSIX: {_security.IsRunningAsMsix()}");
                    sb.AppendLine($"Self-sign verify: {_security.SelfVerifySignature()}");
                }

                var displays = _display.GetDisplaySummary();
                sb.AppendLine("[Displays]");
                sb.AppendLine(displays);

                var hash = _security.Sha256(Encoding.UTF8.GetBytes(sb.ToString()));
                sb.AppendLine("[Integrity]");
                sb.AppendLine($"Report SHA-256: {hash}");

                var final = sb.ToString();
                OutputBox.Text = final;

                await _log.AppendSessionAsync(final);

                StatusText.Text = "Diagnostics complete";
            }
            catch (Exception ex)
            {
                OutputBox.Text += $"
[Error]
{ex}";
                StatusText.Text = "Error";
            }
            finally
            {
                RunBtn.IsEnabled = true;
                ExportBtn.IsEnabled = true;
            }
        }

        private void DisplayTestBtn_Click(object sender, RoutedEventArgs e)
        {
            var w = new TestDisplayWindow();
            w.Show();
        }

        private void StressBtn_Click(object sender, RoutedEventArgs e)
        {
            var w = new StressTestWindow();
            w.Owner = this;
            w.ShowDialog();
        }

        private void SecSettingsBtn_Click(object sender, RoutedEventArgs e)
        {
            var w = new SecuritySettingsWindow();
            w.Owner = this;
            w.ShowDialog();
        }

        private void SecMonitorBtn_Click(object sender, RoutedEventArgs e)
        {
            if (SecMonitorBtn.Content?.ToString() == "Start Monitor")
            {
                _secMon.Start();
                SecMonitorBtn.Content = "Stop Monitor";
                StatusText.Text = "Security monitor running";
            }
            else
            {
                _secMon.Stop();
                SecMonitorBtn.Content = "Start Monitor";
                StatusText.Text = "Security monitor stopped";
            }
        }

        private async void ExportBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ExportBtn.IsEnabled = false;
                StatusText.Text = "Exporting & signing...";

                var content = OutputBox.Text;
                if (string.IsNullOrWhiteSpace(content))
                {
                    MessageBox.Show("Run diagnostics first.");
                    return;
                }

                var (path, signature) = await _security.ExportSignedReportAsync(content);
                MessageBox.Show($@"Report saved:
{path}

Signature (Base64):
{signature}");
                StatusText.Text = "Report exported";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Export error: {ex.Message}");
                StatusText.Text = "Export error";
            }
            finally
            {
                ExportBtn.IsEnabled = true;
            }
        }
    }
}
