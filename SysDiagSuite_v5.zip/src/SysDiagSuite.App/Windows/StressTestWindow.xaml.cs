using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using SysDiagSuite.Services;

namespace SysDiagSuite.Windows
{
    public partial class StressTestWindow : Window
    {
        private readonly StressService _stress = new();
        private CancellationTokenSource? _cts;

        public StressTestWindow()
        {
            InitializeComponent();
        }

        private async void StartBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                StartBtn.IsEnabled = false;
                StopBtn.IsEnabled = true;
                int duration = int.TryParse(DurationBox.Text, out var d) ? Math.Max(5, d) : 30;
                string preset = (PresetCombo.SelectedItem as System.Windows.Controls.ComboBoxItem)?.Content?.ToString() ?? "Alpha (light)";
                var cfg = preset.StartsWith("Alpha") ? StressPreset.Alpha : preset.StartsWith("Omega") ? StressPreset.Omega : StressPreset.Custom;
                _cts = new CancellationTokenSource();
                LogBox.Clear();
                Prog.Value = 0;

                await _stress.RunAsync(new StressOptions
                {
                    Duration = TimeSpan.FromSeconds(duration),
                    Preset = cfg,
                    CustomCpuThreads = Environment.ProcessorCount / 2,
                    CustomMemMB = 512,
                    CustomDiskMB = 128
                },
                progress: p => Dispatcher.Invoke(() => { Prog.Value = p; }),
                logger: s => Dispatcher.Invoke(() => { LogBox.AppendText(s + "\n"); LogBox.ScrollToEnd(); }),
                token: _cts.Token);
            }
            finally
            {
                StartBtn.IsEnabled = true;
                StopBtn.IsEnabled = false;
            }
        }

        private void StopBtn_Click(object sender, RoutedEventArgs e)
        {
            _cts?.Cancel();
        }
    }
}
