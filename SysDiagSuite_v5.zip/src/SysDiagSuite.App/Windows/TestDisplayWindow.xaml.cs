using System;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using WF = System.Windows.Forms;

namespace SysDiagSuite.Windows
{
    public partial class TestDisplayWindow : Window
    {
        private DispatcherTimer? _timer;
        private int _tick;
        public TestDisplayWindow()
        {
            InitializeComponent();
            LoadScreens();
            LoadPatterns();
            DrawPattern();
        }

        private void LoadScreens()
        {
            ScreenCombo.ItemsSource = WF.Screen.AllScreens.Select((s, i) => new { Index = i, Label = s.Primary ? $"{i}: {s.DeviceName} (Primary)" : $"{i}: {s.DeviceName}" , Screen = s }).ToList();
            ScreenCombo.SelectedIndex = 0;
        }

        private void LoadPatterns()
        {
            PatternCombo.Items.Add("Color Bars");
            PatternCombo.Items.Add("Grayscale Ramp");
            PatternCombo.Items.Add("Solid Colors");
            PatternCombo.Items.Add("Checkerboard");
            PatternCombo.Items.Add("Moving Box");
            PatternCombo.SelectedIndex = 0;
        }

        private void BtnApply_Click(object sender, RoutedEventArgs e) => DrawPattern();

        private void BtnFullscreen_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic sel = ScreenCombo.SelectedItem!;
                var screen = (WF.Screen)sel.Screen;
                WindowStyle = WindowStyle.None;
                ResizeMode = ResizeMode.NoResize;
                Topmost = true;
                Left = screen.Bounds.Left;
                Top = screen.Bounds.Top;
                Width = screen.Bounds.Width;
                Height = screen.Bounds.Height;
                WindowState = WindowState.Normal;
                WindowState = WindowState.Maximized;
                DrawPattern();
            }
            catch { }
        }

        private void BtnExitFs_Click(object sender, RoutedEventArgs e)
        {
            Topmost = false;
            WindowStyle = WindowStyle.SingleBorderWindow;
            ResizeMode = ResizeMode.CanResize;
            WindowState = WindowState.Normal;
            Width = 800; Height = 500;
        }

        private void DrawPattern()
        {
            PatternCanvas.Children.Clear();
            StopTimer();
            string pattern = (PatternCombo.SelectedItem as System.Windows.Controls.ComboBoxItem)?.Content?.ToString()
                              ?? PatternCombo.SelectedItem?.ToString() ?? "";

            if (pattern == "Color Bars") DrawColorBars();
            else if (pattern == "Grayscale Ramp") DrawGrayscale();
            else if (pattern == "Solid Colors") DrawSolidCycle();
            else if (pattern == "Checkerboard") DrawChecker();
            else if (pattern == "Moving Box") StartMovingBox();
        }

        private void DrawColorBars()
        {
            var colors = new[] { Colors.White, Colors.Yellow, Colors.Cyan, Colors.Green, Colors.Magenta, Colors.Red, Colors.Blue, Colors.Black };
            double w = PatternCanvas.ActualWidth > 0 ? PatternCanvas.ActualWidth : PatternCanvas.Width;
            if (double.IsNaN(w) || w == 0) w = 800;
            double h = PatternCanvas.ActualHeight > 0 ? PatternCanvas.ActualHeight : PatternCanvas.Height;
            if (double.IsNaN(h) || h == 0) h = 400;
            double bar = w / colors.Length;
            for (int i = 0; i < colors.Length; i++)
            {
                var rect = new Rectangle { Width = bar + 1, Height = h, Fill = new SolidColorBrush(colors[i]) };
                Canvas.SetLeft(rect, i * bar);
                Canvas.SetTop(rect, 0);
                PatternCanvas.Children.Add(rect);
            }
            StatusTxt.Text = "Color Bars";
        }

        private void DrawGrayscale()
        {
            int steps = 32;
            double w = PatternCanvas.ActualWidth > 0 ? PatternCanvas.ActualWidth : 800;
            double h = PatternCanvas.ActualHeight > 0 ? PatternCanvas.ActualHeight : 400;
            double bar = w / steps;
            for (int i = 0; i < steps; i++)
            {
                byte g = (byte)(i * 255 / (steps - 1));
                var rect = new Rectangle { Width = bar + 1, Height = h, Fill = new SolidColorBrush(Color.FromRgb(g, g, g)) };
                Canvas.SetLeft(rect, i * bar);
                Canvas.SetTop(rect, 0);
                PatternCanvas.Children.Add(rect);
            }
            StatusTxt.Text = "Grayscale Ramp";
        }

        private void DrawSolidCycle()
        {
            var colors = new[] { Colors.Black, Colors.White, Colors.Red, Colors.Green, Colors.Blue };
            int idx = 0;
            _timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1.5) };
            _timer.Tick += (s, e) =>
            {
                var rect = new Rectangle { Width = PatternCanvas.ActualWidth > 0 ? PatternCanvas.ActualWidth : 800, Height = PatternCanvas.ActualHeight > 0 ? PatternCanvas.ActualHeight : 400, Fill = new SolidColorBrush(colors[idx]) };
                PatternCanvas.Children.Clear();
                PatternCanvas.Children.Add(rect);
                idx = (idx + 1) % colors.Length;
            };
            _timer.Start();
            StatusTxt.Text = "Solid Colors (cycling)";
        }

        private void DrawChecker()
        {
            double w = PatternCanvas.ActualWidth > 0 ? PatternCanvas.ActualWidth : 800;
            double h = PatternCanvas.ActualHeight > 0 ? PatternCanvas.ActualHeight : 400;
            int cells = 16;
            double cw = w / cells;
            double ch = h / cells;
            for (int y = 0; y < cells; y++)
            {
                for (int x = 0; x < cells; x++)
                {
                    bool dark = ((x + y) % 2 == 0);
                    var rect = new Rectangle { Width = cw + 1, Height = ch + 1, Fill = dark ? Brushes.Black : Brushes.White };
                    Canvas.SetLeft(rect, x * cw);
                    Canvas.SetTop(rect, y * ch);
                    PatternCanvas.Children.Add(rect);
                }
            }
            StatusTxt.Text = "Checkerboard";
        }

        private void StartMovingBox()
        {
            double w = PatternCanvas.ActualWidth > 0 ? PatternCanvas.ActualWidth : 800;
            double h = PatternCanvas.ActualHeight > 0 ? PatternCanvas.ActualHeight : 400;
            var box = new Rectangle { Width = 100, Height = 100, Fill = Brushes.White, Stroke = Brushes.Black };
            PatternCanvas.Children.Add(box);
            double x = 0, y = 0, vx = 6, vy = 4;
            _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(16) };
            _timer.Tick += (s, e) =>
            {
                x += vx; y += vy;
                if (x < 0 || x + box.Width > PatternCanvas.ActualWidth) vx = -vx;
                if (y < 0 || y + box.Height > PatternCanvas.ActualHeight) vy = -vy;
                Canvas.SetLeft(box, x);
                Canvas.SetTop(box, y);
            };
            _timer.Start();
            StatusTxt.Text = "Moving Box (motion/flicker)";
        }

        private void StopTimer()
        {
            if (_timer != null) { _timer.Stop(); _timer = null; }
        }
    }
}
