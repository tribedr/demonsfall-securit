using System.Linq;
using System.Windows;
using SysDiagSuite.Services;

namespace SysDiagSuite.Windows
{
    public partial class SecuritySettingsWindow : Window
    {
        private readonly ConfigService _cfgSvc = new();
        private readonly PasswordService _pw = new();
        private readonly SecurityProtocolsService _proto = new();
        private SecurityConfig _cfg;

        public SecuritySettingsWindow()
        {
            InitializeComponent();
            _cfg = _cfgSvc.LoadSecurity();
            ChkFullscreen.IsChecked = _cfg.ShowFullscreenAlert;
            ChkLock.IsChecked = _cfg.LockWorkstationOnBreach;
            ChkDefender.IsChecked = _cfg.RunDefenderQuickScan;
            WebhookBox.Text = string.Join("\n", _cfg.WebhookUrls ?? new string[0]);
            SmtpHostBox.Text = _cfg.SmtpHost;
            SmtpPortBox.Text = _cfg.SmtpPort.ToString();
            SmtpSslChk.IsChecked = _cfg.SmtpUseSsl;
            SmtpUserBox.Text = _cfg.SmtpUser;
            EmailToBox.Text = _cfg.EmailTo;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            _cfg.ShowFullscreenAlert = ChkFullscreen.IsChecked == true;
            _cfg.LockWorkstationOnBreach = ChkLock.IsChecked == true;
            _cfg.RunDefenderQuickScan = ChkDefender.IsChecked == true;
            _cfg.WebhookUrls = (WebhookBox.Text ?? "").Split(new[] { '\r', '\n' }, System.StringSplitOptions.RemoveEmptyEntries).ToArray();
            _cfg.SmtpHost = SmtpHostBox.Text ?? "";
            _cfg.SmtpPort = int.TryParse(SmtpPortBox.Text, out var p) ? p : 587;
            _cfg.SmtpUseSsl = SmtpSslChk.IsChecked == true;
            _cfg.SmtpUser = SmtpUserBox.Text ?? "";
            if (!string.IsNullOrWhiteSpace(SmtpPassBox.Password)) _cfg.SmtpPassProtected = ConfigService.Protect(SmtpPassBox.Password);
            _cfg.EmailTo = EmailToBox.Text ?? "";
            _cfgSvc.SaveSecurity(_cfg);
            MessageBox.Show("Security settings saved.");
        }

        private void Close_Click(object sender, RoutedEventArgs e) => Close();
    }
}

        private async void SetMp_Click(object sender, RoutedEventArgs e)
        {
            if (MpBox.Password?.Length < 8) { MessageBox.Show("Password too short (min 8)."); return; }
            var ok = await _pw.SetMasterPasswordAsync(MpBox.Password);
            MessageBox.Show(ok ? "Master password set." : "Failed to set password.");
        }

        private async void ArmA65_Click(object sender, RoutedEventArgs e)
        {
            var ok = await _proto.ArmA65Async(MpBox.Password ?? "");
            MessageBox.Show(ok ? "A65 armed." : "Invalid master password.");
        }

        private async void DisarmA65_Click(object sender, RoutedEventArgs e)
        {
            var ok = await _proto.DisarmA65Async(MpBox.Password ?? "");
            MessageBox.Show(ok ? "A65 disarmed." : "Invalid master password.");
        }
