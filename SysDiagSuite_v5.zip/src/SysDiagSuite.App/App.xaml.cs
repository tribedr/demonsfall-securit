using System.Windows;
namespace SysDiagSuite
{
    public partial class App : Application { }
}
