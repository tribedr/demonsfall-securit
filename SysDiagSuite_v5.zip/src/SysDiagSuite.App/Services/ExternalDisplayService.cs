using System.Management;
using System.Text;

namespace SysDiagSuite.Services
{
    public sealed class ExternalDisplayService
    {
        public string GetDisplaySummary()
        {
            var sb = new StringBuilder();

            using (var vc = new ManagementObjectSearcher("SELECT Name,DriverVersion,AdapterRAM FROM Win32_VideoController"))
            {
                foreach (ManagementObject mo in vc.Get())
                {
                    sb.AppendLine($"Adapter: {mo["Name"]} (Driver {mo["DriverVersion"]})");
                }
            }

            using (var mon = new ManagementObjectSearcher("SELECT Name,PNPDeviceID FROM Win32_DesktopMonitor"))
            {
                int i = 1;
                foreach (ManagementObject mo in mon.Get())
                {
                    sb.AppendLine($"Display {i++}: {mo["Name"]} [{mo["PNPDeviceID"]}]");
                }
            }

            return sb.Length == 0 ? "No displays found (WMI query failed)" : sb.ToString().TrimEnd();
        }
    }
}
