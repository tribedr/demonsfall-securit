using System;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading.Tasks;

namespace SysDiagSuite.Services
{
    public sealed class GpuService
    {
        public Task<string> GetGpuSummaryAsync() => Task.Run(() =>
        {
            var sb = new StringBuilder();
            try
            {
                using var searcher = new ManagementObjectSearcher("select * from Win32_VideoController");
                foreach (ManagementObject obj in searcher.Get())
                {
                    sb.AppendLine($"Name: {obj["Name"]}");
                    sb.AppendLine($"DriverVersion: {obj["DriverVersion"]}");
                    sb.AppendLine($"AdapterRAM: {obj["AdapterRAM"]}");
                    sb.AppendLine($"Status: {obj["Status"]}");
                    sb.AppendLine();
                }
            }
            catch (Exception ex)
            {
                sb.AppendLine($"GPU WMI failed: {ex.Message}");
            }

            try
            {
                // Some systems expose GPU engine counters
                var cat = new PerformanceCounterCategory("GPU Engine");
                var instances = cat.GetInstanceNames();
                var counters = instances.SelectMany(i => cat.GetCounters(i)).Where(c => c.CounterName == "Utilization Percentage").ToList();
                if (counters.Count > 0)
                {
                    float total = 0;
                    foreach (var c in counters) total += c.NextValue();
                    sb.AppendLine($"Approx GPU Utilization: {total}%");
                }
            }
            catch { sb.AppendLine("GPU load unavailable"); }

            return sb.ToString();
        });
    }
}
