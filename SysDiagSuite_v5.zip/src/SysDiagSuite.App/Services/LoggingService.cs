using System;
using System.IO;
using System.Threading.Tasks;

namespace SysDiagSuite.Services
{
    public sealed class LoggingService
    {
        private static string LogDir => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SysDiagSuite", "Logs");

        public async Task AppendSessionAsync(string text)
        {
            Directory.CreateDirectory(LogDir);
            var path = Path.Combine(LogDir, $"session_{DateTime.UtcNow:yyyyMMdd}.log");
            await File.AppendAllTextAsync(path, $"[{DateTime.UtcNow:O}]\n{text}\n\n");
        }
    }
}
