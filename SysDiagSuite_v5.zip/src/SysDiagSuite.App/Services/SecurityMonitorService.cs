using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace SysDiagSuite.Services
{
    public sealed class SecurityMonitorService
    {
        private FileSystemWatcher? _honeyWatch;
        private CancellationTokenSource? _cts;
        private readonly AlertService _alert = new();
        private readonly SecurityProtocolsService _proto = new();
        private int _honeyEvents = 0;

        private static string HoneyDir => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SysDiagSuite", "honey");
        private static string HoneyFile => Path.Combine(HoneyDir, "do_not_touch.txt");

        public void Start()
        {
            if (_cts != null) return;
            Directory.CreateDirectory(HoneyDir);
            if (!File.Exists(HoneyFile)) File.WriteAllText(HoneyFile, "This is a honeypot file for tamper detection.");

            _honeyWatch = new FileSystemWatcher(HoneyDir) { EnableRaisingEvents = true, IncludeSubdirectories = false };
            _honeyWatch.Changed += OnHoneyEvent;
            _honeyWatch.Deleted += OnHoneyEvent;
            _honeyWatch.Renamed += OnHoneyEvent;

            _cts = new CancellationTokenSource();
            Task.Run(() => PollEventLogAsync(_cts.Token));
        }

        public void Stop()
        {
            _cts?.Cancel();
            _cts = null;
            if (_honeyWatch != null)
            {
                _honeyWatch.EnableRaisingEvents = false;
                _honeyWatch.Dispose();
                _honeyWatch = null;
            }
        }

        private async Task PollEventLogAsync(CancellationToken token)
        {
            // Poll Application log for crash bursts as a simple anomaly signal
            DateTime last = DateTime.UtcNow;
            while (!token.IsCancellationRequested)
            {
                try
                {
                    int count = 0;
                    var log = new EventLog("Application");
                    foreach (EventLogEntry e in log.Entries)
                    {
                        if (e.TimeGenerated.ToUniversalTime() > DateTime.UtcNow.AddMinutes(-1) && e.EntryType == EventLogEntryType.Error)
                            count++;
                    }
                    if (count > 50)
                    {
                        await _proto.TriggerO63Async("Extreme error burst", $"Detected {count} error events in the last minute.");
                    }
                }
                catch { }
                await Task.Delay(15000, token);
            }
        }

        private async void OnHoneyEvent(object sender, FileSystemEventArgs e)
        {
            _honeyEvents++;
            if (_honeyEvents >= 3)
            {
                await _proto.TriggerO63Async("Repeated honeypot tampering", $"{e.ChangeType}: {e.FullPath} ({_honeyEvents} events)");
                _honeyEvents = 0;
            }
            else
            {
                await _alert.TriggerAsync("Honeypot tampering", $"{e.ChangeType}: {e.FullPath}", "A65");
            }
        }
    }
}
