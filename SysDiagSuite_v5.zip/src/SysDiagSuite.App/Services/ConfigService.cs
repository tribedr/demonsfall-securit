using System;
using System.IO;
using System.Security.Cryptography;
using System.Text.Json;

namespace SysDiagSuite.Services
{
    public sealed class SecurityConfig
    {
        public bool LockWorkstationOnBreach { get; set; } = false;
        public bool RunDefenderQuickScan { get; set; } = false;
        public bool ShowFullscreenAlert { get; set; } = true;
        public string[] WebhookUrls { get; set; } = Array.Empty<string>();

        // Email (optional)
        public string SmtpHost { get; set; } = "";
        public int SmtpPort { get; set; } = 587;
        public bool SmtpUseSsl { get; set; } = true;
        public string SmtpUser { get; set; } = "";
        public string SmtpPassProtected { get; set; } = ""; // DPAPI protected
        public string EmailTo { get; set; } = "";

        // Master password (PBKDF2 hashed, salt stored; DPAPI-protected blob)
        public string MpSalt { get; set; } = "";
        public string MpHash { get; set; } = "";
        public bool A65Armed { get; set; } = false; // Advanced Alpha 65 armed
    }

    public sealed class ConfigService
    {
        private static string Dir => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SysDiagSuite");
        private static string PathCfg => System.IO.Path.Combine(Dir, "security.json");

        public SecurityConfig LoadSecurity()
        {
            try
            {
                if (File.Exists(PathCfg))
                {
                    var json = File.ReadAllText(PathCfg);
                    return JsonSerializer.Deserialize<SecurityConfig>(json) ?? new SecurityConfig();
                }
            }
            catch { }
            return new SecurityConfig();
        }

        public void SaveSecurity(SecurityConfig cfg)
        {
            Directory.CreateDirectory(Dir);
            var json = JsonSerializer.Serialize(cfg, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(PathCfg, json);
        }

        public static string Protect(string plain)
        {
            try
            {
                if (string.IsNullOrEmpty(plain)) return "";
                var bytes = System.Text.Encoding.UTF8.GetBytes(plain);
                var enc = ProtectedData.Protect(bytes, null, DataProtectionScope.CurrentUser);
                return Convert.ToBase64String(enc);
            }
            catch { return ""; }
        }

        public static string Unprotect(string prot)
        {
            try
            {
                if (string.IsNullOrEmpty(prot)) return "";
                var bytes = Convert.FromBase64String(prot);
                var dec = ProtectedData.Unprotect(bytes, null, DataProtectionScope.CurrentUser);
                return System.Text.Encoding.UTF8.GetString(dec);
            }
            catch { return ""; }
        }
    }
}
