using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading.Tasks;

namespace SysDiagSuite.Services
{
    public sealed class DiagnosticService
    {
        public Task<string> GetSystemInfoAsync() => Task.Run(() =>
        {
            var sb = new StringBuilder();
            using var mos = new ManagementObjectSearcher("SELECT Caption,Version,OSArchitecture FROM Win32_OperatingSystem");
            foreach (ManagementObject mo in mos.Get())
                sb.AppendLine($"{mo["Caption"]} {mo["Version"]} ({mo["OSArchitecture"]})");

            using var bios = new ManagementObjectSearcher("SELECT Manufacturer,SMBIOSBIOSVersion,ReleaseDate FROM Win32_BIOS");
            foreach (ManagementObject mo in bios.Get())
                sb.AppendLine($"BIOS: {mo["Manufacturer"]} {mo["SMBIOSBIOSVersion"]}");

            using var comp = new ManagementObjectSearcher("SELECT Manufacturer,Model FROM Win32_ComputerSystem");
            foreach (ManagementObject mo in comp.Get())
                sb.AppendLine($"System: {mo["Manufacturer"]} {mo["Model"]}");

            return sb.ToString().TrimEnd();
        });

        public Task<string> CpuQuickAsync() => Task.Run(() =>
        {
            var sb = new StringBuilder();
            using var procs = new ManagementObjectSearcher("SELECT Name,NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed FROM Win32_Processor");
            foreach (ManagementObject mo in procs.Get())
            {
                sb.AppendLine($"{mo["Name"]}");
                sb.AppendLine($"Cores/Threads: {mo["NumberOfCores"]}/{mo["NumberOfLogicalProcessors"]}");
                sb.AppendLine($"Max Clock: {mo["MaxClockSpeed"]} MHz");
            }
            var sw = Stopwatch.StartNew();
            double x = 0;
            for (int i = 0; i < 10_000_000; i++) x += Math.Sqrt(i);
            sw.Stop();
            sb.AppendLine($"Quick compute loop: {sw.ElapsedMilliseconds} ms");
            return sb.ToString().TrimEnd();
        });

        public Task<string> MemoryAsync() => Task.Run(() =>
        {
            using var q = new ManagementObjectSearcher("SELECT TotalVisibleMemorySize,FreePhysicalMemory FROM Win32_OperatingSystem");
            var mo = q.Get().Cast<ManagementObject>().First();
            var total = Convert.ToUInt64(mo["TotalVisibleMemorySize"]) * 1024;
            var free = Convert.ToUInt64(mo["FreePhysicalMemory"]) * 1024;
            return $"RAM Total: {FormatBytes(total)}\nRAM Free: {FormatBytes(free)}";
        });

        public Task<string> DiskDeepAsync() => Task.Run(() =>
        {
            var sb = new StringBuilder();
            using var diskQ = new ManagementObjectSearcher("SELECT Name,Model,Size FROM Win32_DiskDrive");
            foreach (ManagementObject mo in diskQ.Get())
                sb.AppendLine($"{mo["Model"]} ({mo["Name"]}) Size: {FormatBytes(Convert.ToUInt64(mo["Size"]))}");

            var tmp = Path.Combine(Path.GetTempPath(), "sd_diag_test.bin");
            var rand = new byte[64 * 1024 * 1024];
            new Random(42).NextBytes(rand);

            var sw = Stopwatch.StartNew();
            File.WriteAllBytes(tmp, rand);
            sw.Stop();
            var writeMBps = 64.0 / sw.Elapsed.TotalSeconds;

            sw.Restart();
            var read = File.ReadAllBytes(tmp);
            sw.Stop();
            var readMBps = 64.0 / sw.Elapsed.TotalSeconds;

            try { File.Delete(tmp); } catch { }

            sb.AppendLine($"Sequential write: {writeMBps:F1} MB/s");
            sb.AppendLine($"Sequential read:  {readMBps:F1} MB/s");
            return sb.ToString().TrimEnd();
        });

        private static string FormatBytes(ulong bytes)
        {
            string[] units = { "B", "KB", "MB", "GB", "TB" };
            double value = bytes;
            int unit = 0;
            while (value >= 1024 && unit < units.Length - 1) { value /= 1024; unit++; }
            return $"{value:F1} {units[unit]}";
        }
    }
}
