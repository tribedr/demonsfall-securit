using System;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace SysDiagSuite.Services
{
    public sealed class EmailService
    {
        private readonly ConfigService _cfgSvc = new();

        public async Task SendAsync(string subject, string body)
        {
            var cfg = _cfgSvc.LoadSecurity();
            if (string.IsNullOrWhiteSpace(cfg.SmtpHost) || string.IsNullOrWhiteSpace(cfg.EmailTo)) return;

            using var client = new SmtpClient(cfg.SmtpHost, cfg.SmtpPort)
            {
                EnableSsl = cfg.SmtpUseSsl
            };
            if (!string.IsNullOrWhiteSpace(cfg.SmtpUser))
            {
                client.Credentials = new NetworkCredential(cfg.SmtpUser, ConfigService.Unprotect(cfg.SmtpPassProtected));
            }

            var from = string.IsNullOrWhiteSpace(cfg.SmtpUser) ? "sysdiagsuite@localhost" : cfg.SmtpUser;
            var mail = new MailMessage(from, cfg.EmailTo, subject, body);
            try { await client.SendMailAsync(mail); } catch { }
        }
    }
}
