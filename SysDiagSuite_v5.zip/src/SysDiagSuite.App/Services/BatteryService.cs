using System;
using System.Management;
using System.Text;
using System.Threading.Tasks;

namespace SysDiagSuite.Services
{
    public sealed class BatteryService
    {
        public Task<string> GetBatterySummaryAsync() => Task.Run(() =>
        {
            var sb = new StringBuilder();
            try
            {
                using var searcher = new ManagementObjectSearcher("select * from Win32_Battery");
                foreach (ManagementObject obj in searcher.Get())
                {
                    sb.AppendLine($"Name: {obj["Name"]}");
                    sb.AppendLine($"Status: {obj["Status"]}");
                    sb.AppendLine($"EstimatedChargeRemaining: {obj["EstimatedChargeRemaining"]}%");
                    sb.AppendLine($"BatteryStatus: {obj["BatteryStatus"]}");
                }
                if (sb.Length == 0)
                    sb.Append("No battery detected");
            }
            catch (Exception ex)
            {
                sb.Append($"Battery info unavailable: {ex.Message}");
            }
            return sb.ToString();
        });
    }
}
