using System;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace SysDiagSuite.Services
{
    public sealed class PasswordService
    {
        private readonly ConfigService _cfgSvc = new();

        public Task<bool> SetMasterPasswordAsync(string newPassword)
        {
            return Task.Run(() =>
            {
                if (string.IsNullOrWhiteSpace(newPassword) || newPassword.Length < 8) return false;
                var cfg = _cfgSvc.LoadSecurity();
                var salt = RandomNumberGenerator.GetBytes(16);
                using var pbkdf2 = new Rfc2898DeriveBytes(newPassword, salt, 100_000, HashAlgorithmName.SHA256);
                var hash = pbkdf2.GetBytes(32);
                cfg.MpSalt = Convert.ToBase64String(salt);
                cfg.MpHash = Convert.ToBase64String(hash);
                _cfgSvc.SaveSecurity(cfg);
                return true;
            });
        }

        public Task<bool> VerifyAsync(string password)
        {
            return Task.Run(() =>
            {
                var cfg = _cfgSvc.LoadSecurity();
                if (string.IsNullOrEmpty(cfg.MpSalt) || string.IsNullOrEmpty(cfg.MpHash)) return false;
                var salt = Convert.FromBase64String(cfg.MpSalt);
                var expected = Convert.FromBase64String(cfg.MpHash);
                using var pbkdf2 = new Rfc2898DeriveBytes(password, salt, 100_000, HashAlgorithmName.SHA256);
                var hash = pbkdf2.GetBytes(32);
                return CryptographicOperations.FixedTimeEquals(hash, expected);
            });
        }
    }
}
