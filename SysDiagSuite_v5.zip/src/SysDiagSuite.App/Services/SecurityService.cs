using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace SysDiagSuite.Services
{
    public sealed class SecurityService
    {
        public bool IsRunningAsMsix()
        {
            try
            {
                // Windows AppModel API presence implies packaged context
                var pkg = Windows.ApplicationModel.Package.Current;
                _ = pkg.Id; // access to ensure it's available
                return true;
            }
            catch { return false; }
        }

        public bool SelfVerifySignature()
        {
            // Simple self-check: sign & verify a token using the per-installation keypair
            try
            {
                var rsa = GetOrCreateKeyPairAsync().GetAwaiter().GetResult();
                byte[] data = Encoding.UTF8.GetBytes("SysDiagSuite::SelfTest");
                var sig = rsa.SignData(data, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
                return rsa.VerifyData(data, sig, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            }
            catch { return false; }
        }

        private static string KeyDir => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SysDiagSuite", "keys");
        private static string ReportsDir => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "SysDiagSuite", "Reports");

        public string Sha256(byte[] data)
        {
            using var sha = SHA256.Create();
            return Convert.ToHexString(sha.ComputeHash(data));
        }

        public async Task<(string path, string signature)> ExportSignedReportAsync(string content)
        {
            Directory.CreateDirectory(ReportsDir);
            Directory.CreateDirectory(KeyDir);

            var kp = await GetOrCreateKeyPairAsync();
            var bytes = Encoding.UTF8.GetBytes(content);
            var sig = kp.SignData(bytes, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            var sigB64 = Convert.ToBase64String(sig);

            var ts = DateTime.UtcNow.ToString("yyyyMMdd_HHmmss");
            var path = Path.Combine(ReportsDir, $"SysDiag_Report_{ts}.txt");

            await File.WriteAllTextAsync(path,
$@"SysDiagSuite Signed Report
UTC: {DateTime.UtcNow:O}

{content}

--- SIGNATURE ---
Algorithm: RSA-PKCS1-SHA256
PublicKeyXml:
{kp.ToXmlString(false)}
Signature(Base64):
{sigB64}
");

            return (path, sigB64);
        }

        private async Task<RSACryptoServiceProvider> GetOrCreateKeyPairAsync()
        {
            var priv = Path.Combine(KeyDir, "report_signing.key");
            if (File.Exists(priv))
            {
                var xml = await File.ReadAllTextAsync(priv);
                var rsa = new RSACryptoServiceProvider(2048);
                rsa.FromXmlString(xml);
                return rsa;
            }
            else
            {
                var rsa = new RSACryptoServiceProvider(2048);
                var xml = rsa.ToXmlString(true);
                await File.WriteAllTextAsync(priv, xml);
                return rsa;
            }
        }
    }
}
