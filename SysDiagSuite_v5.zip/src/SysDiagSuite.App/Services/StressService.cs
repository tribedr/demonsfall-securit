using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SysDiagSuite.Services
{
    public enum StressPreset { Alpha, Omega, Custom }

    public sealed class StressOptions
    {
        public StressPreset Preset { get; set; } = StressPreset.Alpha;
        public TimeSpan Duration { get; set; } = TimeSpan.FromSeconds(30);
        public int CustomCpuThreads { get; set; } = 2;
        public int CustomMemMB { get; set; } = 256;
        public int CustomDiskMB { get; set; } = 64;
    }

    public sealed class StressService
    {
        public async Task RunAsync(StressOptions options, Action<double>? progress = null, Action<string>? logger = null, CancellationToken token = default)
        {
            int cpuThreads, memMB, diskMB;
            switch (options.Preset)
            {
                case StressPreset.Alpha: cpuThreads = Math.Max(1, Environment.ProcessorCount / 4); memMB = 256; diskMB = 64; break;
                case StressPreset.Omega: cpuThreads = Math.Max(2, Environment.ProcessorCount - 1); memMB = 1024; diskMB = 512; break;
                default: cpuThreads = options.CustomCpuThreads; memMB = options.CustomMemMB; diskMB = options.CustomDiskMB; break;
            }

            logger?.Invoke($"Starting stress: CPU={cpuThreads} threads, MEM={memMB}MB, DISK={diskMB}MB, Duration={options.Duration.TotalSeconds}s");

            var end = DateTime.UtcNow + options.Duration;
            byte[] mem = new byte[memMB * 1024 * 1024];
            new Random(42).NextBytes(mem);

            // CPU workers
            var workers = Enumerable.Range(0, cpuThreads).Select(i => Task.Run(() =>
            {
                double x = 0;
                var rnd = new Random(i + 7);
                while (!token.IsCancellationRequested && DateTime.UtcNow < end)
                {
                    for (int k = 0; k < 200000; k++) x += Math.Sqrt(rnd.NextDouble());
                }
            }, token)).ToArray();

            // Disk churn
            var temp = Path.Combine(Path.GetTempPath(), "SysDiagSuite_Stress.bin");
            var diskTask = Task.Run(() =>
            {
                try
                {
                    var block = new byte[4 * 1024 * 1024];
                    var rng = new Random(99);
                    int written = 0;
                    using var fs = new FileStream(temp, FileMode.Create, FileAccess.ReadWrite, FileShare.None, 4096, FileOptions.WriteThrough | FileOptions.SequentialScan);
                    while (!token.IsCancellationRequested && DateTime.UtcNow < end && written < diskMB)
                    {
                        rng.NextBytes(block);
                        fs.Write(block, 0, Math.Min(block.Length, (diskMB - written) * 1024 * 1024));
                        fs.Flush();
                        fs.Position = 0;
                        fs.Read(block, 0, block.Length);
                        written += block.Length / (1024 * 1024);
                    }
                }
                catch { }
                finally { try { File.Delete(temp); } catch { } }
            }, token);

            // Progress loop
            while (!token.IsCancellationRequested && DateTime.UtcNow < end)
            {
                var remain = (end - DateTime.UtcNow).TotalSeconds;
                var pct = 100.0 * (options.Duration.TotalSeconds - remain) / options.Duration.TotalSeconds;
                progress?.Invoke(Math.Max(0, Math.Min(100, pct)));
                await Task.Delay(250, token);
            }

            await Task.WhenAll(Task.WhenAll(workers), diskTask);

            progress?.Invoke(100);
            logger?.Invoke("Stress completed");
        }
    }
}
