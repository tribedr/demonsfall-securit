using System;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using SysDiagSuite.Models;

namespace SysDiagSuite.Services
{
    public sealed class NetworkService
    {
        public Task<string> NetworkSummaryAsync(ProtocolMode mode) => Task.Run(async () =>
        {
            var sb = new StringBuilder();
            var ifs = NetworkInterface.GetAllNetworkInterfaces()
                .Where(n => n.OperationalStatus == OperationalStatus.Up)
                .ToArray();

            foreach (var ni in ifs)
            {
                var ipProps = ni.GetIPProperties();
                var ipv4 = ipProps.UnicastAddresses.FirstOrDefault(a => a.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)?.Address;
                sb.AppendLine($"{ni.Name} [{ni.NetworkInterfaceType}] - IPv4: {ipv4}");
            }

            string host = "8.8.8.8";
            using var p = new Ping();
            try
            {
                var reply = await p.SendPingAsync(host, 2000);
                sb.AppendLine($"Ping {host}: {reply.Status} {reply.RoundtripTime} ms");
            }
            catch (Exception ex) { sb.AppendLine($"Ping {host}: error {ex.Message}"); }

            if (mode == ProtocolMode.Omega)
            {
                string[] hosts = { "1.1.1.1", "8.8.4.4", "9.9.9.9" };
                foreach (var h in hosts)
                {
                    try
                    {
                        var r = await p.SendPingAsync(h, 2000);
                        sb.AppendLine($"Ping {h}: {r.Status} {r.RoundtripTime} ms");
                    }
                    catch (Exception ex) { sb.AppendLine($"Ping {h}: error {ex.Message}"); }
                }
            }

            return sb.ToString().TrimEnd();
        });
    }
}
