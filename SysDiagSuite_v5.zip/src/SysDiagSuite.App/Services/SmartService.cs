using System;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading.Tasks;

namespace SysDiagSuite.Services
{
    // Queries basic SMART status via WMI (root\wmi). Works on many systems; gracefully degrades if unavailable.
    public sealed class SmartService
    {
        public Task<string> GetSmartSummaryAsync() => Task.Run(() =>
        {
            var sb = new StringBuilder();
            try
            {
                var scope = new ManagementScope(@"\\.\root\wmi");
                scope.Connect();

                // Overall predictive failure status
                using var statusQ = new ManagementObjectSearcher(scope, new ObjectQuery("SELECT InstanceName, PredictFailure FROM MSStorageDriver_FailurePredictStatus"));
                foreach (ManagementObject mo in statusQ.Get())
                {
                    var inst = (string)mo["InstanceName"];
                    var fail = (bool)mo["PredictFailure"];
                    sb.AppendLine($"{inst} -> PredictFailure: {fail}");
                }

                if (sb.Length == 0) sb.Append("No SMART entries found");
            }
            catch (Exception ex)
            {
                sb.Append($"SMART unavailable: {ex.Message}");
            }
            return sb.ToString();
        });
    }
}
