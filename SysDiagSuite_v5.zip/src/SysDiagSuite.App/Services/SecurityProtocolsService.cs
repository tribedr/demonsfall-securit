using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace SysDiagSuite.Services
{
    public sealed class SecurityProtocolsService
    {
        private readonly PasswordService _pw = new();
        private readonly ConfigService _cfgSvc = new();
        private readonly AlertService _alert = new();

        [DllImport("user32.dll")] private static extern bool LockWorkStation();

        public async Task<bool> ArmA65Async(string masterPassword)
        {
            if (!await _pw.VerifyAsync(masterPassword)) return false;
            var cfg = _cfgSvc.LoadSecurity();
            cfg.A65Armed = true;
            _cfgSvc.SaveSecurity(cfg);
            await _alert.TriggerAsync("Advanced Alpha 65 armed", "System is in heightened monitoring mode.", "A65");
            return true;
        }

        public async Task<bool> DisarmA65Async(string masterPassword)
        {
            if (!await _pw.VerifyAsync(masterPassword)) return false;
            var cfg = _cfgSvc.LoadSecurity();
            cfg.A65Armed = false;
            _cfgSvc.SaveSecurity(cfg);
            await _alert.TriggerAsync("Advanced Alpha 65 disarmed", "System returned to normal monitoring.", "A65");
            return true;
        }

        // Defensive Omega 63: extreme lockdown + alerts (non-destructive)
        public async Task TriggerO63Async(string reason, string details)
        {
            var cfg = _cfgSvc.LoadSecurity();
            await _alert.TriggerAsync(reason, details, "O63");
            try { if (cfg.LockWorkstationOnBreach) LockWorkStation(); } catch { }
        }
    }
}
