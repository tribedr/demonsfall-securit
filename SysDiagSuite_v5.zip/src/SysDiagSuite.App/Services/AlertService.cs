using System;
using System.Diagnostics;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace SysDiagSuite.Services
{
    public sealed class AlertService
    {
        private readonly ConfigService _cfgSvc = new();
        private readonly EmailService _email = new();
        private readonly SecurityService _secSvc = new();

        [DllImport("user32.dll")]
        private static extern bool LockWorkStation();

        public async Task TriggerAsync(string reason, string details, string protocol = "")
        {
            var cfg = _cfgSvc.LoadSecurity();

            // Event log (best effort)
            try
            {
                EventLog.WriteEntry("Application", $"SysDiagSuite alert {protocol}: {reason}\n{details}", EventLogEntryType.Warning);
            }
            catch { /* ignore */ }

            // Fullscreen alert
            if (cfg.ShowFullscreenAlert)
            {
                Application.Current.Dispatcher.Invoke(() =>
                {
                    var win = new Window
                    {
                        WindowStyle = WindowStyle.None,
                        WindowState = WindowState.Maximized,
                        Topmost = true,
                        Background = Brushes.DarkRed,
                        Content = new TextBlock
                        {
                            Text = $"SECURITY ALERT\n{reason}\n\n{details}\n\nPress ESC to close",
                            Foreground = Brushes.White,
                            FontSize = 36,
                            TextAlignment = TextAlignment.Center,
                            VerticalAlignment = VerticalAlignment.Center
                        }
                    };
                    win.KeyDown += (s, e) => { if (e.Key == System.Windows.Input.Key.Escape) win.Close(); };
                    win.Show();
                });
            }

            // Optional lock workstation
            if (cfg.LockWorkstationOnBreach)
            {
                try { LockWorkStation(); } catch { }
            }

            // Optional Defender quick scan
            if (cfg.RunDefenderQuickScan)
            {
                try
                {
                    string mp = Environment.ExpandEnvironmentVariables(@"%ProgramFiles%\Windows Defender\MpCmdRun.exe");
                    if (System.IO.File.Exists(mp))
                    {
                        Process.Start(new ProcessStartInfo
                        {
                            FileName = mp,
                            Arguments = "-Scan -ScanType 1",
                            UseShellExecute = false,
                            CreateNoWindow = true
                        });
                    }
                }
                catch { }
            }

            // Webhook notify
            if (cfg.WebhookUrls != null && cfg.WebhookUrls.Length > 0)
            {
                try
                {
                    using var http = new HttpClient();
                    var payload = new { source = "SysDiagSuite", utc = DateTime.UtcNow, protocol, reason, details };
                    var json = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");
                    foreach (var url in cfg.WebhookUrls)
                    {
                        try { await http.PostAsync(url, json); } catch { }
                    }
                }
                catch { }
            }
        }
    }
}

        // Email
        try { await _email.SendAsync($"SysDiagSuite Alert {protocol}: {reason}", details); } catch { }
